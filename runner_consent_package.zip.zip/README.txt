
README - Déploiement facile du jeu "Runner avec consentement"

Contenu du package:
- index.html  -> le jeu (ouvre ce fichier dans un navigateur pour tester localement)
- assets/scream.png  -> image d'exemple (placeholder)
- assets/scream.mp3  -> son d'exemple (placeholder)

Étapes rapides pour obtenir un lien partageable (débutants, mobile-friendly):

Option A — Netlify Drop (très simple):
1. Télécharge ce fichier zip sur ton ordinateur/smartphone.
2. Va sur https://app.netlify.com/drop
3. Glisse-dépose le zip. Netlify va héberger ton site et te donner un lien du genre: https://nomrandom.netlify.app
4. Remplace les assets dans le dossier "assets" si tu veux ta propre image/son (tu peux re-téleverser un nouveau zip pour mettre à jour le site).

Option B — Glitch (édition en ligne facile, bon pour modifier):
1. Crée un compte sur https://glitch.com (ou connecte-toi).
2. Clique sur New Project → "Import from GitHub" ou "hello-webpage".
3. Dans l'éditeur, remplace le contenu de index.html par le code du fichier index.html présent ici (ou importe le zip avec l'interface).
4. Téléverse tes fichiers dans le dossier "assets". Glitch fournit un lien partageable automatiquement.

Option C — GitHub Pages (un peu plus d'étapes mais gratuit et stable):
1. Crée un repo GitHub privé ou public.
2. Upload de tous les fichiers (index.html et dossier assets).
3. Dans Settings → Pages, active GitHub Pages sur la branche main et dossier / (root).
4. Tu auras un lien du type https://TonPseudo.github.io/nomrepo/

Notes importantes:
- Remplace 'assets/scream.png' et 'assets/scream.mp3' par ton image/son. ATTENTION: n'utilise que des fichiers que tu possèdes ou libres de droits.
- Toujours avertir la personne de ce qu'elle va voir et s'assurer qu'elle consent. Même si la page demande un consentement, dis-lui avant d'envoyer le lien.
- Mobile: la page supporte les tap (toucher) pour sauter. Les navigateurs mobiles exigent souvent une interaction (touche/clic) pour autoriser le son; c'est pris en compte.
- Si tu veux, je peux: 
  * remplacer les placeholders par l'image que tu veux (tu peux uploader l'image ici), 
  * ou te guider pas-à-pas pour déployer sur Netlify/Glitch/GitHub Pages.

Bonne chance — dis-moi si tu veux que je mette ton image dans le package maintenant.
